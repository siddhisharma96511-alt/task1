# Hello World Task

This project contains a simple HTML page that displays "Hello World!" in a web browser.

## Files
- index.html
- README.md

## How to Run
1. Open index.html in any web browser.
2. The page will display "Hello World!".